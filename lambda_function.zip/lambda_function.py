import boto3
import time
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    try:
        # Initialize Boto3 clients
        ec2_client = boto3.client('ec2')
        ec2_resource = boto3.resource('ec2')
        ses_client = boto3.client('ses')

        # Set parameters
        golden_ami_id = 'ami-0c9fe376728d15eca' 
        subnet_id = 'subnet-0f0256c557e80f7d1'
        key_name = 'nvirginia'
        instance_type = 't2.micro'
        security_group_ids = ['sg-0e7441e3ced14cb98']
        iam_instance_profile_arn = 'arn:aws:iam::975049892759:instance-profile/r2'
        sender_email = 'rithik.narula@ranosys.com'
        recipient_email = 'rithik.narula32@gmail.com'
        username = "ec2-user"

        # Create EC2 instances using Golden AMI
        instance_ids = create_ec2_instances(ec2_resource, golden_ami_id, subnet_id, key_name, instance_type, security_group_ids, iam_instance_profile_arn)
        if instance_ids:
            # Get instance IPs (both private and public)
            while True:
                instance_ips = get_instance_ips(ec2_client, instance_ids)
                if instance_ips:
                    # Get username and key name of the instance
                    instance_info = get_instance_info(ec2_client, instance_ids[0])
                    username = instance_info.get('username', 'ec2-user')
                    key_name = instance_info.get('key_name', 'Unknown')
                    
                    # Send email with instance IPs, username, and key name
                    send_email(ses_client, sender_email, recipient_email, instance_ips, username, key_name)
                    
                    return {
                        'statusCode': 200,
                        'body': 'EC2 instances created successfully. Email sent with instance IPs, username, and key name.'
                    }
                time.sleep(10)  
        else:
            logger.error("Failed to create EC2 instances.")
            return {
                'statusCode': 400,
                'body': 'Failed to create EC2 instances.'
            }
    except Exception as e:
        logger.error(f"Error in lambda_handler: {e}")
        return {
            'statusCode': 500,
            'body': f"Error: {str(e)}"
        }

def create_ec2_instances(ec2_resource, golden_ami_id, subnet_id, key_name, instance_type, security_group_ids, iam_instance_profile_arn):
    try:
        instance_ids = []
        create_instance = ec2_resource.create_instances(ImageId=golden_ami_id,
                                                        MinCount=1,
                                                        MaxCount=1,
                                                        InstanceType=instance_type,
                                                        KeyName=key_name,
                                                        SecurityGroupIds=security_group_ids,
                                                        SubnetId=subnet_id,
                                                        IamInstanceProfile={'Arn': iam_instance_profile_arn}
                                                    )
        instance_id = create_instance[0].id
        instance_ids.append(instance_id)
        logger.info(f"Instance created with ID: {instance_id}")
        return instance_ids
    except Exception as e:
        logger.error(f"Error in create_ec2_instances: {e}")
        return []

def get_instance_ips(ec2_client, instance_ids):
    try:
        instance_ips = []
        for instance_id in instance_ids:
            response = ec2_client.describe_instances(InstanceIds=[instance_id])
            reservations = response.get('Reservations', [])
            for reservation in reservations:
                instances = reservation.get('Instances', [])
                for instance in instances:
                    state = instance.get('State', {}).get('Name', 'Unknown')
                    if state == "running":
                        private_ip = instance.get('PrivateIpAddress')
                        public_ip = instance.get('PublicIpAddress')
                        if private_ip and public_ip:
                            instance_ips.append({
                                'private_ip': private_ip,
                                'public_ip': public_ip
                            })
        logger.info(f"Instance IPs: {instance_ips}")
        return instance_ips
    except Exception as e:
        logger.error(f"Error in get_instance_ips: {e}")
        return []

def get_instance_info(ec2_client, instance_id):
    try:
        response = ec2_client.describe_instances(InstanceIds=[instance_id])
        reservations = response.get('Reservations', [])
        for reservation in reservations:
            instances = reservation.get('Instances', [])
            for instance in instances:
                username = instance.get('UserName', 'Unknown')
                key_name = instance.get('KeyName', 'Unknown')
                return {'username': username, 'key_name': key_name}
    except Exception as e:
        logger.error(f"Error in get_instance_info: {e}")
        return {'username': 'Unknown', 'key_name': 'Unknown'}

def send_email(ses_client, sender_email, recipient_email, instance_ips, username, key_name):
    try:
        # Compose email message
        subject = 'EC2 Instance IP Notification'
        body_text = 'EC2 instances have been launched.\n\n'
        for idx, ips in enumerate(instance_ips, 1):
            body_text += f'Instance {idx}:\nPrivate IP: {ips["private_ip"]}\nPublic IP: {ips["public_ip"]}\n\n'
        body_text += f'Username: {username}\nKey Name: {key_name}'

        # Send email
        response = ses_client.send_email(
            Source=sender_email,
            Destination={
                'ToAddresses': [recipient_email]
            },
            Message={
                'Subject': {'Data': subject},
                'Body': {'Text': {'Data': body_text}}
            }
        )
        logger.info(f"Email sent to {recipient_email}")
    except Exception as e:
        logger.error(f"Error in send_email: {e}")
